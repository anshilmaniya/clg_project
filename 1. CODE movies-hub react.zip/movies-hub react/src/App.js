// import logo from './logo.svg';
import './App.css';
import Rounting from './componets/Routing';
import Navigation from './componets/Navigation';

function App() {
  return (
    <div className="App">
      <Navigation />
      <main>
        <Rounting />
      </main>
    </div>
  );
}

export default App;
