import React from "react"
import { NavLink,useNavigate } from "react-router-dom";

import "./Home.css";
const Homepage = () => {
    const navigate = useNavigate();
    function adding() {
        var storaged = JSON.parse(localStorage.getItem("user-details")) || [];
        var inputemail = document.getElementById("input-value").value;
        console.log(inputemail);
        console.log(storaged);
        var emailExists = storaged.some((item) => {
            return (item.emailed === inputemail);
        });
        // console.log(emailExists);
        if (emailExists) {
            navigate("/mainhub");
        }
        else {
            alert("Email-address is not Exists");
        }
    }

    function opennav() {
        document.getElementById("Frequently-2").style.width = "auto";
        document.getElementById("Frequently-2").style.display = "block";
        document.getElementById("additionsign").style.display = "none";
        // alert("Aa")
    }
    function remove() {
        document.getElementById("Frequently-2").style.display = "none";
        document.getElementById("additionsign").style.display = "block";

    }
    function opennav3() {
        document.getElementById("Frequently-3").style.width = "auto";
        document.getElementById("Frequently-3").style.display = "block";
        document.getElementById("additionsign-3").style.display = "none";
    }
    function remove3() {
        document.getElementById("Frequently-3").style.display = "none";
        document.getElementById("additionsign-3").style.display = "block";

    }
    function opennav4() {
        document.getElementById("Frequently-4").style.width = "auto";
        document.getElementById("Frequently-4").style.display = "block";
        document.getElementById("additionsign-4").style.display = "none";
    }
    function remove4() {
        document.getElementById("Frequently-4").style.display = "none";
        document.getElementById("additionsign-4").style.display = "block";

    }
    function opennav5() {
        document.getElementById("Frequently-5").style.width = "auto";
        document.getElementById("Frequently-5").style.display = "block";
        document.getElementById("additionsign-5").style.display = "none";
    }
    function remove5() {
        document.getElementById("Frequently-5").style.display = "none";
        document.getElementById("additionsign-5").style.display = "block";
    }


    // var alldata = []
    // function sumited() {
    //     var question = document.getElementById("Questions-1").value;
    //     document.getElementById("Questions-1").value = "";
    //     console.log(question, "question");
    //     var answer = document.getElementById("answer").value;
    //     document.getElementById("answer").value = "";
    //     console.log(answer, "answer");
    //     var alldataobject = {
    //         question1: question,
    //         answer1: answer
    //     };
    //     alldata.push(alldataobject);
    //     console.log(alldata);
    //     document.getElementById("Frequently-1").innerHTML = alldata.map((item, index) => {
    //         return `<div id="${`objectalldata${index}`}">
    //     <p class="Frequently-1-1" onClick="opennav(${index})" id="Frequently-1-1">${item.question1}</p>
    //     <p class="Frequently-2" id="Frequently-2" onClick={()=>remove()}>${item.answer1}</p>
    //     </div>`;
    //     }).join("")
    // }

    return (
        <>
            <div className="main-page">
                <div className="page-1">
    
                    <div className="unlimited-movie">
                        <div className="unlimited-movie-1">
                            <div className="unlimited-movie-1-1">
                                <h1> Unlimited movies, TV shows and more</h1>
                                <h4 style={{ fontWeight: "100" }}>Watch anywhere. Cancel anytime.</h4>
                                <h4 style={{ fontWeight: "100" }}>Ready to watch? Enter your email to create or restart your membership.
                                </h4>
                            </div>
                            <div className="get-start">
                                <input type="email" placeholder="Email address" id="input-value" />
                                <button className="start" id="start" onClick={() => adding()}>Get started</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-2">
                    <div className="page-2-1">
                        <div className="enjoy-tv-2">
                            <img src="tv.png" height="100%" width="100%" className="img-2" />
                            <div className="enjoy-tv-2-1">
                                <video height="100%" width="100%" autoPlay loop muted>
                                    <source
                                        src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/video-tv-in-0819.m4v"
                                        type="video/mp4" />
                                </video>
                            </div>
                        </div>
                        <div className="enjoy-tv-1">
                            <div className="enjoy-tv-1-1">
                                <h1 className="enjoy-tv-1-3">Enjoy on your TV</h1>
                                <div className="enjoy-tv-1-2">
                                    <h5>Watch on smart TVs, PlayStation, Xbox,</h5>
                                    <h5>Chromecast, Apple TV, Blu-ray players and</h5>
                                    <h5>more.</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-3">
                    <div className="page-2-1">
                        <div className="enjoy-tv-2">
                            <img src="mobile-0819.jpg" height="100%" width="100%" className="img-2" />
                        </div>
                        <div className="enjoy-tv-1">
                            <div className="enjoy-tv-1-1">
                                <h1 className="enjoy-tv-1-3">Download your</h1>
                                <h1 className="enjoy-tv-1-3">shows to watch</h1>
                                <div className="enjoy-tv-1-2">
                                    <h5>Watch on smart TVs, PlayStation, Xbox,</h5>
                                    <h5>Chromecast, Apple TV, Blu-ray players and</h5>
                                    <h5>more.</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-4">
                    <div className="page-2-1">
                        <div className="enjoy-tv-2">
                            <img src="device-pile-in.png" className="img-2" height="100%" width="100%" />
                            <div className="enjoy-tv-3-1">
                                <video width="280px" autoPlay loop muted>
                                    <source
                                        src="https://assets.nflxext.com/ffe/siteui/acquisition/ourStory/fuji/desktop/video-devices-in.m4v"
                                        type="video/mp4" />
                                </video>
                            </div>
                        </div>
                        <div className="enjoy-tv-1">
                            <div className="enjoy-tv-1-1">
                                <h1 className="enjoy-tv-1-3">Watch everywhere</h1>
                                <div className="enjoy-tv-1-2">
                                    <h5>Stream unlimited movies and TV shows on</h5>
                                    <h5>your phone, tablet, laptop, and TV.</h5>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-5">
                    <div className="page-2-1">
                        <div className="enjoy-tv-2">
                            <img src="AAAABVr8nYuAg0xDpXDv0VI9HUoH7r2aGp4TKRCsKNQrMwxzTtr-NlwOHeS8bCI2oeZddmu3nMYr3j9MjYhHyjBASb1FaOGYZNYvPBCL.png"
                                height="100%" width="100%" className="img-2" />

                        </div>
                        <div className="enjoy-tv-1">
                            <div className="enjoy-tv-1-1">
                                <h1 className="enjoy-tv-1-3">Create profiles for kids</h1>
                                <div className="enjoy-tv-1-2">
                                    <h5>Watch on smart TVs, PlayStation, Xbox,</h5>
                                    <h5>Chromecast, Apple TV, Blu-ray players and</h5>
                                    <h5>more.</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-6">
                    <div className="Frequently">
                        <h1>Frequently Asked Questions</h1>
                        <div className="Frequently-1">
                            <div className="Frequently-1-1" onClick={()=>opennav()}>
                                <h3>what is movies-hub?</h3>
                                <img src="addition.png" alt="addition" height="30px" onClick={()=>opennav()} id="additionsign" />
                            </div>
                            <div className="Frequently-2" id="Frequently-2" onClick={()=>remove()} style={{ cursor: "pointer" }}>
                                <h2>Netflix is a streaming service that offers a wide variety of award
                                    winning TV shows, movies, anime, documentaries and more on thousands of internet-connected
                                    devices.</h2>
                            </div>
                        </div>

                        <div className="Frequently-1">
                            <div className="Frequently-1-1" onClick={()=>opennav3()}>
                                <h3>how match movies-hub cost?</h3>
                                <img src="addition.png" alt="addition" style={{ float: "right", cursor: "pointer" }} height="30px"
                                    onClick={()=>opennav3()} id="additionsign-3" />
                            </div>
                            <div className="Frequently-2" id="Frequently-3" onClick={()=>remove3()} style={{ cursor: "pointer" }}>

                                <h2>Watch Netflix on your smartphone, tablet, Smart TV, laptop, or
                                    streaming device, all for one fixed monthly fee. Plans range from ₹149 to ₹649 a month. No
                                    extra costs, no contracts.</h2>
                            </div>
                        </div>
                        <div className="Frequently-1">
                            <div className="Frequently-1-1" onClick={()=>opennav4()}>
                                <h3>where can I watch?</h3>
                                <img src="addition.png" alt="addition" height="30px" onClick={()=>opennav4()} id="additionsign-4" />
                            </div>
                            <div className="Frequently-2" id="Frequently-4" onClick={()=>remove4()} style={{ cursor: "pointer" }}>
                                <h2>Watch anywhere, anytime. Sign in with your Netflix account to watch
                                    instantly on the web at netflix.com from your personal computer or on any internet-connected
                                    device that offers the Netflix app, including smart TVs, smartphones, tablets, streaming
                                    media players and game consoles.</h2>
                            </div>
                        </div>
                        <div className="Frequently-1">
                            <div className="Frequently-1-1" onClick={()=>opennav5()}>
                                <h3>where can I cancle?</h3>
                                <img src="addition.png" alt="addition" height="30px" onClick={()=>opennav5()} id="additionsign-5" />
                            </div>
                            <div className="Frequently-2" id="Frequently-5" onClick={()=>remove5()} style={{ cursor: "pointer" }}>
                                <h2>Watch anywhere, anytime. Sign in with your Netflix account to watch
                                    instantly on the web at netflix.com from your personal computer or on any internet-connected
                                    device that offers the Netflix app, including smart TVs, smartphones, tablets, streaming
                                    media players and game consoles.</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-7">
                    <div className="Questions">
                        <div className="Questions-1">
                            <h5 className="Questions-1-1">Questions? Call <a href="#">000-800-919-1694</a></h5>
                        </div>
                        <div className="Questions-2">
                            <div className="Questions-2-1">
                                <h5 className="Questions-1-1"> <a href="">FAQ</a></h5>
                                <h5 className="Questions-1-1"><a href="">Investor Relations</a></h5>
                                <h5 className="Questions-1-1"><a href="">Privacy</a></h5>
                                <h5 className="Questions-1-1"><a href="">Speed Test</a></h5>
                            </div>
                            <div className="Questions-2-1">
                                <h5 className="Questions-1-1"><a href="help-center.html">
                                    Help Centre</a></h5>
                                <h5 className="Questions-1-1"><a href="#">Jobs</a></h5>
                                <h5 className="Questions-1-1"><a href="#">Cookie Preferences</a></h5>
                                <h5 className="Questions-1-1"><a href="#">Legal Notices</a></h5>
                            </div>
                            <div className="Questions-2-1">
                                <h5 className="Questions-1-1"><a href="#">
                                    Account</a></h5>
                                <h5 className="Questions-1-1"><a href="#">
                                    Ways to Watch</a></h5>
                                <h5 className="Questions-1-1"><a href="#">
                                    Corporate Information</a></h5>
                                <h5 className="Questions-1-1"><a href="#">
                                    Only on Netflix</a></h5>
                            </div>
                            <div className="Questions-2-1">
                                <h5 className="Questions-1-1"><a href="#">
                                    Media Centre</a></h5>
                                <h5 className="Questions-1-1"><a href="#">Terms of Use</a></h5>
                                <h5 className="Questions-1-1"><a href="contect.html">
                                    Contact Us</a></h5>
                                <h5 className="Questions-1-1"><a href="#">
                                    Us</a></h5>

                            </div>
                        </div>
                        <div className="Questions-3">
                            <select>
                                <option value="English">English</option>
                                <option value="English">हिंदी </option>
                            </select>
                            <h5 className="Questions-1-1"> movies-hub India</h5>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Homepage;