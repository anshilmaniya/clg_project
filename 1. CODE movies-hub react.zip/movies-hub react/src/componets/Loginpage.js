import React from "react";
import { NavLink,useNavigate } from "react-router-dom";

import "./Login.css"
const Loginpage = () => {
    const navigate = useNavigate();

    function submited() {
        var storaged = JSON.parse(localStorage.getItem("user-details")) || [];
        var inputemail = document.getElementById("input-email").value;
        var inputpassword = document.getElementById("input-password").value;
        var emailExists = storaged.some((item) => {
            return (item.emailed === inputemail) && (item.pass === inputpassword);
        });
        if (emailExists) {
            navigate("/mainhub");
        }
        else {
            alert("you need to register");
        }
    }
    function inputvalue() {
        var inputvalue = document.getElementById("input-email").value;
        var netflixdiv = document.getElementById("erroring");
        var inputerror = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (inputerror.test(inputvalue)) {
            netflixdiv.textContent = "";
        } else {
            netflixdiv.textContent = "Please enter a valid email address.";
        }
    }
    function toggle() {
        var inputpassword = document.getElementById("input-password");
        if (inputpassword.type === "password") {
            inputpassword.type = "text";
        } else {
            inputpassword.type = "password";
        }
    }
    return (
        <>
            <div class="nav-bar">
                {/* <div class="nav-bar-1">
                <!-- <img src="movies_hub-removebg-preview.png" height="180px"> -->
            </div> */}
            </div>
            <div class="login-page">
                <div class="login-page-1">
                    <div class="sign">
                        <div class="sign-1">
                            <h2>Sign In</h2>
                        </div>
                        <div>
                            <div class="input" id="inputon">
                                <div class="input-email">
                                    <input type="email" id="input-email" class="input-value" placeholder="Enter Email"
                                        onInput={()=>inputvalue()} required />
                                    <div id="erroring" style={{ color: "red" }}>
                                    </div>
                                    <div class="input-1">
                                        <input type="password" id="input-password" class="input-value"
                                            placeholder="Enter password" required />
                                        <input type="checkbox" class="input-checkbox" onClick={()=>toggle()} />
                                    </div>
                                    <div id="erroring-1" style={{ color: "red" }}></div>

                                    <div class="sign-button">
                                        <button id="sign-in" type="submit" onClick={()=>submited()}>submit</button>
                                        <h3 class="OR">OR</h3>
                                        <h3 class="OR" style={{ cursor: "pointer" }} >Forget password?</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Loginpage;
