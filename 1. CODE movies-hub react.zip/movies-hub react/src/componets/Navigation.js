import { NavLink } from "react-router-dom";
import "./Home.css";

const Navigation = () => {
    return (
        <>

            <div className="nav-bar">
                <div className="nav-bar-1">
                    <div className="movies-hub">
                        <img src="movies_hub-removebg-preview.png" height="100%" />
                    </div>

                    <div className="sign-in">
                        <select>
                            <option value="English">English</option>
                            <option value="हिंदी">हिंदी </option>
                        </select>
                        <NavLink to="/register">register</NavLink>
                        <div className="drop-down">
                            <img src="profile-user.png" alt="profile-user.png" style={{ cursor: "pointer" }} height="30px" />
                            <div className="language">
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>About</a>
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>services </a>
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>Watch </a>
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>Email-us</a>
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>Clients</a>
                                <a style={{ color: "black", padding: "17px", width: "100px" }}>Contact</a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </>
    )
};

export default Navigation;
