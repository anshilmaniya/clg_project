import React from "react";
import { Routes, Route } from "react-router-dom";
import Registerpage from './Registerpage';
import Homepage from './Homepage';
import Loginpage from './Loginpage';
import Mainhub from './Mainhub';
import Trailar from './Trailar';

export default function Rounting() {
  return (
    <>
      <Routes>
        <Route index path="/" element={<Homepage />} />
        <Route path="/register" element={<Registerpage />} />
        <Route path="/login" element={<Loginpage />} />
        <Route path="/mainhub" element={<Mainhub />} />
        <Route path="/trailar" element={<Trailar />} />
        <Route path="*" element={<Homepage />} />
      </Routes>
    </>
  );
}