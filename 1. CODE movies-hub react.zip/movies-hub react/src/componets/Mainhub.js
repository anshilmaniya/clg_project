import React, { useEffect, useState } from "react";
import "./Mainhub.css"
import axios from "axios";
import { useLocation, useNavigate } from "react-router-dom";


const Mainhub = () => {
    const navigate = useNavigate();
    const { state } = useLocation();
    const [data, setData] = useState([]);
    const theprice = (res) => {
        console.log(res);
        navigate("/trailar", { state: { res } })
    }

    useEffect(() => {
        axios.get("/moviedata.json").then((res) => {
            setData(res.data);
        })
        // console.log(data);
    }, []);


    return (
        <>
            <div className="main-page">
                <div className="page-1">
                    <header>
                        <div className="main">
                        </div>
                    </header>
                    <div className="Discover">
                        <div className="Discover-1">
                            <div className="Discover-1-1">
                                <h1>Discover stories and</h1>
                                <h1>experiences to share with</h1>
                                <h1>India.</h1>
                            </div>
                            <div className="Discover-1-2">
                                {/* <input type="text" placeholder="Serch for Netfix title and news" className="search" /> */}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="interested">
                    <div className="interested-1">
                        <h2>I'm interested in covering titles releasing in</h2>
                        <select className="months">
                            <option style={{ backgroundColor: "black", fontSize: "15px" }}>January</option>
                            <option style={{ backgroundColor: "black" }}>February</option>
                            <option style={{ backgroundColor: "black" }}>March</option>
                            <option style={{ backgroundColor: "black" }}>April</option>
                            <option style={{ backgroundColor: "black" }}>May</option>
                        </select>
                    </div>
                    <div className="interested-2">
                        <div className="interested-2-1">
                            <div className="film">
                                <img src="film.png" height="15px" />
                                <h5>Film</h5>
                            </div>
                            <div className="film" style={{ width: "90px" }}>
                                <img src="episodes.png" height="15px" />
                                <h5>Series</h5>
                            </div>
                            <div className="film" style={{ width: "140px" }}>
                                <img src="documentary.png" height="15px" />
                                <h5>Documentary</h5>
                            </div>
                            <div className="film">
                                <img src="vr-glasses.png" height="15px" />
                                <h5>Kids</h5>
                            </div>
                            <div className="film" style={{ width: "90px" }}>
                                <img src="comedy-podcast.png" height="15px" />
                                <h5>Riality</h5>
                            </div>
                            <div className="film" style={{ width: "170px" }}>
                                <img src="game.png" height="15px" />
                                <h5>Stand-Up-Comedy</h5>
                            </div>
                            <div className="film" style={{ width: "90px" }}>
                                <img src="film.png" height="15px" />
                                <h5>Game</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="page-2">
                    <div className="movie">
                        {data.map((value, index) => {
                            return (<div className="movie-1" key={index}>
                                <img src={value.poster} width="100%" height="100%" onClick={() => theprice(value)} />
                            </div>)
                        }
                        )}
                    </div>
                </div>
            </div>
        </>
    )
}
export default Mainhub;