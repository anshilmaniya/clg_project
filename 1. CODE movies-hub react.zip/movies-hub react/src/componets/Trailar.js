import React, { useEffect, useState } from "react";
// import "./Mainhub.css"
import "./trailar.css"
import { useLocation, useNavigate } from "react-router-dom";

const Trailar = () => {
    const { state } = useLocation();
    const [data, setData] = useState([]);
    const { trailer, title, year, language, genre, rating } = data;
    console.log(trailer);
    useEffect(() => {
        setData(state.res);
    }, []);

    return (
        <>
            <div className="trailerfor">
                <div className="trailerfor-2">
                    <div>{title}</div>
                    <div style={{ fontSize: "15px" }}>year : {year}</div>
                    <div style={{ fontSize: "15px" }}>genre : {genre}</div>
                    <div style={{ fontSize: "15px" }}>language : {language}</div>
                    <div style={{ fontSize: "15px" }}>rating : {rating}</div>
                </div>
                <div className="trailerfor-1">
                    <iframe width="100%" height="100%" src={trailer}></iframe>
                </div>
            </div>
        </>
    )
}

export default Trailar;