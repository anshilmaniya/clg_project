import React from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css"
const Registerpage = () => {
    const navigate = useNavigate();
    function registed() {
        var Fullname = document.getElementById("full-name-input").value;
        var number = document.getElementById("Enter-number").value;
        var Enteremail = document.getElementById("Enter-Email").value;
        var Password = document.getElementById("Enter-Password").value;
        var inputerror1 = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        var registerobject = {
            name: Fullname,
            nub: number,
            emailed: Enteremail,
            pass: Password
        };
        // console.log("1",registerobject);
        var storaged = JSON.parse(localStorage.getItem("user-details")) || [];
        console.log(storaged);

        var userinfo = storaged.some((items) => {
            return items.emailed === Enteremail;
        });
        if (userinfo) {
            alert("User already existes.");
        }
        else if (Fullname === "") {
            alert("pls Enter Fullname");
        }
        else if (number === "") {
            alert("pls Enter number");
        }
        else if (Enteremail === "") {
            alert("pls Enter email");
        }
        else if (!inputerror1.test(Enteremail)) {
            alert("Email is not valid");
        }
        else if (Password === "") {
            alert("pls Enter Password");
        }

        else {
            storaged.push(registerobject);
            localStorage.setItem("user-details", JSON.stringify(storaged));
            navigate("/login");

        }
    }

    function watchpassword() {
        var inputpassword1 = document.getElementById("Enter-Password");
        if (inputpassword1.type === "password") {
            inputpassword1.type = "text";
        } else {
            inputpassword1.type = "password";
        }
    }
    function emailvalid() {
        var inputvalue1 = document.getElementById("Enter-Email").value;
        var netflixdiv1 = document.getElementById("email-invalidation");
        var inputerror1 = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (inputerror1.test(inputvalue1)) {
            netflixdiv1.textContent = "";
        } else {
            netflixdiv1.textContent = "Please enter a valid email address.";
        }
    }
    return (
        <>
            <div id="register-page">
                <div id="register-main">
                    <div id="register">
                        <h2>Register</h2>
                    </div>
                    <div id="full-name">
                        <input type="text" placeholder="Your full-name" id="full-name-input" className="full-name-input" required />
                    </div>
                    <div id="nub-requird">
                        <input type="text" placeholder="Enter-number" id="Enter-number" className="full-name-input" maxlength="10" required />
                        <div id="nub-invalidation"></div>
                    </div>
                    <div id="email-requird">
                        <input type="email" placeholder="Enter-Email" id="Enter-Email" onInput={() => emailvalid()} className="full-name-input" required />
                        <div id="email-invalidation"></div>
                    </div>
                    <div id="full-name-1">
                        <input type="password" placeholder="Enter-Password" id="Enter-Password" required className="full-name-input" />
                        <input type="checkbox" id="checked" onClick={() => watchpassword()} />
                    </div>
                    <div id="button" >
                        <button type="button" onClick={() => registed()}>Register</button>
                    </div>
                </div>
            </div>
        </>
    )
}
export default Registerpage;
